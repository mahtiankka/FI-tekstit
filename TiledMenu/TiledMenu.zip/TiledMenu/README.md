# Tiled Menu

Käännös valmiina käyttöönne, olkaa hyvä.

Pakattu kansio sisältää kaksi tiedostoa.

Valmiin (fi.po) suomikäännöksen Tiled Menu -ohjelmasta. Voit editoida ja muuttaa tiedostoa/käännöstä poedit ohjelmalla. 

Valmis (plasma_applet_com.github.zren.tiledmenu.mo) muotoon käännetty kielipaketti, jonka kopioidaan kohteeseen;
usr/share/plasma/plasmoids/com.github.zren.tiledmenu/contents/locale/fi/LC_MESSAGES

Jos olet asentanut Tiled Menun KDE Storen kautta sinun kotihakemistoon niin silloin polku on;
local/share/plasma/plasmoids/com.github.zren.tiledmenu/contents/locale/fi/LC_MESSAGES

Kirjaudu uudelleen ja Tiled Menu on suomenkielinen.

Huomaa! Asenna ensin Tiled Menu ja kopioi sen jälkeen kielipaketti.

Tiled Menu testattu toivaksi Feren OS.
Päivä 10.6.2021

Valmistajan kotisivu:
https://github.com/Zren/plasma-applet-tiledmenu

KDE Store:
https://store.kde.org/p/1160672


