# Gnome-Pie versio 0.7.2

Käännös valmiina käyttöönne, olkaa hyvä.

Pakattu kansio sisältää kaksi tiedostoa.

Valmiin (gnomepie.po) suomikäännös GnomePie-ohjelmasta. Voit editoida ja muuttaa tiedostoa/käännöstä poedit ohjelmalla. 

Valmis (gnomepie.mo) muotoon käännetty kielipaketti, jonka kopioidaan kohteeseen;
/usr/share/locale/fi/LC_MESSAGES/gnomepie.mo

Käynnistä Gnome-Pie uudelleen ja ympäristö on suomenkielinen.

Gnome-Pie v0.7.2 testattu 21.11.2020
Linux Mint 20 Cinnamon
Linux Mint 20 Mate
Ubuntu 20.10  Gnome 

Valmistajan kotisivu:
https://schneegans.github.io/gnome-pie.html

Gnome-Pie kääntäjiin voit liittyä täällä:
https://translate.zanata.org/project/view/gnome-pie

Lisenssi:
MIT License

