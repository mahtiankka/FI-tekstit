# Variety 0.8.3

Käännös valmiina käyttöönne, olkaa hyvä.

Pakattu kansio sisältää kaksi tiedostoa.

Valmiin (fi.po) suomikäännöksen Variety ohjelmasta. Voit editoida ja muuttaa tiedostoa/käännöstä poedit ohjelmalla. 

Valmis (variety.mo) muotoon käännetty kielipaketti, jonka kopioidaan kohteeseen;
/usr/share/locale/fi/LC_MESSAGES/variety.mo

Käynnistä Variety uudelleen ja ympäristö on suomenkielinen.

Variety v0.8.3 Linux Mint 20 Cinnamon
Testattu 3.11.2020

Valmistajan kotisivu:
https://peterlevi.com/variety/

GitHub:
https://github.com/varietywalls/variety

Lisenssi:
GNU GPL Version 3
