# VLC 3.0.12

Käännös valmiina käyttöönne, olkaa hyvä.

Pakattu kansio sisältää kaksi tiedostoa.

Valmiin (vlc-30_fi.po) suomikäännöksen VLC ohjelmasta. Voit editoida ja muuttaa tiedostoa/käännöstä poedit ohjelmalla. 

Valmis (vlc.mo) muotoon käännetty kielipaketti, jonka kopioidaan kohteeseen;
/usr/share/locale/fi/LC_MESSAGES/vlc.mo

Käynnistä VLC uudelleen ja ympäristö on suomenkielinen.

Huomaa! Asenna ensin VLC mediasoitin ja kopioi sen jälkeen vlc.mo kielipaketti vanhan päälle. Ohjelman asennus korvaa kielipaketin omallaan noin vuoden vanhalla kielipaketilla, joten asenna ohjelma ensin.

VLC versiolla 3.0.9.2 testattu toivaksi Linux Mint 20.1 Cinnamon.
Päivä 4.3.2021

Valmistajan kotisivu:
https://www.videolan.org/

Lisenssi:
GNU GENERAL PUBLIC LICENSE Version 2

